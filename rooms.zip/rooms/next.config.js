module.exports = { reactStrictMode: true }
